/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author t00019474
 */
public class AreaHandler 
{ 
	public double circleArea(double radius) 
	{ 
		  double value=(radius*radius*Math.PI); 
		  return value; 
	} 
} 

