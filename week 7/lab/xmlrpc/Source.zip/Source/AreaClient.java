/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author t00019474
 */
import java.io.IOException;
import java.net.URL;
import java.util.Vector;
import org.apache.xmlrpc.*;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

public class AreaClient {

    public static void main(String args[]) {
//        if (args.length < 1) {
//            System.out.println("Usage: java AreaClient [radius]");
//            System.exit(-1);
//        }
        AreaClient client = new AreaClient();
        //double radius = Double.parseDouble(args[0]);
        

//main() contd…
        try {
            double radius = 10;
            double area = client.areaCircle(radius);
// Report the results 
            System.out.println("The area of the circle would be: " + area);
        } catch (Exception e) {
            System.out.println("IO Exception: " + e.getMessage());
        }
    } //end of main

//contd…
    public double areaCircle(double radius) throws IOException, XmlRpcException {
// Create the client, identifying the server 
        XmlRpcClient client = new XmlRpcClient();
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:8899/"));
        client.setConfig(config);
        
        //XmlRpcClient client("http://localhost:8899/");
// Create the request parameters using user input
        Vector params = new Vector();
        params.addElement(new Double(radius));
// Issue a request 
        Object result = client.execute("AreaHandler.circleArea", params); 
        String resultStr = result.toString();
        double area = Double.parseDouble(resultStr);
        return area;
    }
} //end of the class
