/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author t00019474
 */
import java.io.IOException;
import org.apache.xmlrpc.server.PropertyHandlerMapping;
import org.apache.xmlrpc.webserver.WebServer;        
import org.apache.xmlrpc.*;
import org.apache.xmlrpc.server.XmlRpcServer;
import org.apache.xmlrpc.server.XmlRpcServerConfigImpl;


public class AreaServer {

    public static void main(String[] args) {
//        if (args.length < 1) {
//            System.out.println("Usage: java AreaServer [port]");
//            System.exit(-1);
//        }
        try {
            startServer(args);
        } //contd…
        catch (Exception e) {
            System.out.println("Could not start server: " + e.getMessage());
        }
    }

    public static void startServer(String[] args) throws Exception {
// Start the server, using built-in version 
        System.out.println("Attempting to start XML-RPC Server...");
        //WebServer server = new WebServer(Integer.parseInt(args[0]));
        WebServer server = new WebServer(8899);
        System.out.println("Started successfully."); 
        // Register our handler class as area 
        //server.start();
        
        XmlRpcServer xmlRPCServer = server.getXmlRpcServer();
        
        PropertyHandlerMapping phm = new PropertyHandlerMapping();
        phm.addHandler("AreaHandler", AreaHandler.class);
        
        xmlRPCServer.setHandlerMapping(phm);
        
        XmlRpcServerConfigImpl serverConfig = 
                (XmlRpcServerConfigImpl) xmlRPCServer.getConfig();
        serverConfig.setEnabledForExtensions(true);
        serverConfig.setContentLengthOptional(true);
        
        server.start();
        
        //server.addHandler("area", new AreaHandler());
        //System.out.println("Registered AreaHandler class to area.");
        System.out.println("Now accepting requests. (Halt program to stop.)");
    }
}
